VMwhiz – README
VMwhiz is a PowerShell-based graphical user interface (GUI) application designed to streamline the creation and management of Hyper-V virtual machines (VMs) on Windows platforms. Developed by Rabih HADDAD, VMwhiz provides intuitive experience for IT experts and administrators to efficiently manage VM workflows.
•	Version: 1.0 (pre-release 0.9.1)
•	Release Date: April 08, 2025
•	Publisher: Rabih HADDAD

#Release notes:
#Update 0.9.1
o	UI Enhancements: Improved form layouts, added tooltips, and updated labels for better user experience.
o	Validation: Enhanced input validation for VM names, paths, and configurations.
o	Registry Updates: Added logic to save and retrieve configurations, including disk type, checkpoints, and VM paths.
o	Dynamic Updates: Implemented real-time updates for dropdowns, labels, and progress bars.
o	Error Handling: Improved logging and error messages for better debugging.
o	Update Mechanism: Integrated version checking and update functionality with registry tracking.
o	Resource Calculations: Enhanced VM calculator logic for accurate resource estimation.
o	Cleanup Operations: Added maintenance tasks for cleaning up VMs and resources.
o	Modularization: Refactored functions for better readability and reusability.
o	Fixed VM Connection Issues: Resolved path errors, removed GUI freezes, and improved VM startup reliability.
o	Improved Dropdown Behavior: Ensured the last selected VM is reselected after refreshing, defaulting to the first item if not found.
o	Resolved Timer Errors: Fixed syntax issues to ensure timers run without crashing.
o	Improved GUI Responsiveness: Eliminated blocking delays by relying on asynchronous state checks. 



Overview
VMwhiz simplifies Hyper-V VM management by offering a modern GUI that automates VM provisioning, configuration, and monitoring. Key capabilities include bulk VM creation, resource allocation, real-time status tracking, and seamless integration with Microsoft Hyper-V.
Features
•	VM Management: 
o	Provision multiple VMs with customizable configuration in a single operation.
o	Configure VM settings — including resource, storage, and network — prior to deployment.
o	Deletes VMs and automatically removes their associated file structure, while a dedicated maintenance task manages files locked by Hyper-V for complete cleanup.
•	Advanced Configuration: 
o	Define VM properties such as RAM, vCPUs, disk size, disk type (Dynamic or Fixed), generation (1 or 2), network, and checkpoints through a dedicated settings dialog.



•	Resource Insights: 
o	VM Calculator calculates recommended VM counts based on system resources.
•	Prerequisite Validation: 
o	Detect and optionally install Hyper-V if not present.
o	Ensure administrative privileges and compatible PowerShell/.NET Framework versions.
•	Robust Logging: 
o	In-depth activity and error logs saved to a file and the Windows Event Viewer.
o	Export logs directly from the UI.
User Interface
•	Modern Loading Experience: Display a borderless loading screen with progress bars and status updates for a seamless startup.
•	Styled Controls: Utilize custom GroupBox elements with refined border designs to enhance visual appeal.
•	Dynamic Feedback: Deliver real-time UI updates during VM creation and management tasks, ensuring an interactive experience.
System Requirements
•	Operating System: Windows 10, Windows 11, or Windows Server (Hyper-V capable editions).
•	PowerShell: Version 5.0 or later.
•	.NET Framework: Version 4.5 or higher (optimized for 4.6.2).
•	Hyper-V: Enabled Hyper-V feature (installation offered if missing).
•	Permissions: Administrative rights required for Hyper-V management.
•	Dependencies: 
o	System.Windows.Forms and System.Drawing assemblies.
o	Hyper-V PowerShell module.

Usage
1.	Start VMwhiz: 
o	Launch the .exe. A loading screen validates prerequisites before displaying the main interface.
2.	Main Interface: 
o	VM Name: Specify a base name for new VMs (e.g., "TestVM").
o	Number of VMs: Enter the desired quantity (1–99).
o	Create: Initiates VM creation with sequential suffixes (e.g., "TestVM-01").
o	More: Access advanced configuration options.
o	VM Dropdown: Select existing VMs for connection or deletion.
o	Connect: Starts and connects to the selected VM.
o	Delete: Removes the selected VM and its resources.
o	Save Logs: Exports the status log to a file.
o	Abort/Exit: Cancels operations or exits the application.
3.	More Settings: 
o	Modify VM parameters:
RAM, vCPU, vDiskSize, vDiskType, VM generation, checkpoints, vNetwork, ISO path, and storage location.
o	Save settings for VM provisioning.
4.	Monitoring: 
o	Review real-time operation status in the GUI.
o	Access detailed logs in “VMwhiz_LOG.log” or Event Viewer ("Application" log, source "VMwhiz").



Directory Structure
•	Release: Designated folder for the production-ready VMwhiz.exe.
•	Archive: Recommended for storing versioned builds (e.g., Archive\1.0.1\).
•	ICONS: Contains UI assets (VMwhiz-Icon.ico, vmwhizlogo.png).
Configuration
•	Registry Storage: 
o	Location: HKCU:\Software\R-HADDAD\Applications\VMwhiz\.
o	Keys: Default (baseline settings), UserProfile (user-specific settings).
•	Log file and DB csv:
o	C:\Users\YourUsername\AppData\Roaming\VMwhiz
•	Default Settings: 
o	RAM: 4 GB, vCPUs: 4, Disk: 60 GB (Dynamic), Generation: 2, Network: "Default Switch".

Antivirus Considerations
The VMwhiz executable (VMwhiz.exe) may be flagged as potentially malicious by some antivirus software due to its automation capabilities and system-level interactions with Hyper-V. To mitigate this:
•	Windows Defender Integration: VMwhiz automatically adds VMwhiz.exe to the Windows Defender exclusion list during execution, ensuring uninterrupted operation on systems using Microsoft’s built-in antivirus solution.
•	Third-Party Antivirus: For other antivirus programs (e.g., Norton, McAfee, or Kaspersky), manual intervention is required. You must add VMwhiz.exe to the exclusion or trusted applications list within the respective antivirus software to prevent false positives and ensure full functionality.
Steps for Manual Exclusion
1.	Locate the VMwhiz executable.
2.	Open your antivirus software settings or exclusions panel.
3.	Add the full path to VMwhiz.exe as an excluded or trusted file.
4.	Save changes and verify that VMwhiz operates without interference.

Troubleshooting
•	Hyper-V Missing: Confirm Hyper-V is enabled or allow VMwhiz to install it (requires reboot).
•	Access Denied: Run as Administrator.
•	UI Unresponsive: Review logs for errors; adjust sleep intervals if necessary.
•	Icon Not Found: Verify the ICONS folder is in the script or .exe directory.
License
© 2025 Rabih HADDAD. All rights reserved. 
Support
For issues or feedback, rabih.haddad@outlook.com

